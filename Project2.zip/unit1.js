// This is where you can place your Javascript code

function MButton1Click(event) {
    alert('asdfads');
}
