var PlanetsPage=new Object(Object);

$(document).ready(function(event) {

Canvas_ctx = document.getElementById('Canvas').getContext('experimental-webgl');

});
function PlanetsPageJSLoad(event)
{

   var event = event || window.event;
   var params=null;
        //begin js
        start();
        //end
        
}

var Canvas_ctx;
