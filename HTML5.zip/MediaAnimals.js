var AnimalsPage=new Object(Object);

$(document).ready(function(event) {

});
function iWhaleJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        $("#mWhale").get()[0].play();
        //end
        
}

function iCatJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        $("#mCat").get()[0].play();
        //end
        
}

function iEagleJSClick(event)
{

  var event = event || window.event;
  var params=null;
        //begin js
        $("#mEagle").get()[0].play();
        //end
        
}

