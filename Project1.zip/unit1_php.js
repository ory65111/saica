jQuery('#MPage1').bind('pageinit',function(event){
 	jQuery('#MButton1').bind('click',MButton1Click);

});
